################################################################################################
# Program: Appendix.R
# Author:	Ye Wang
# Data:	Wang_Wong_2017_Main.csv, Wang_Wong_2017_Placebo.csv, Wang_Wong_2017_Graphs.csv, Wang_Wong_2017_Graphs_Placebo.csv
# Aim: Generate tables and graphs in the appendix of Wang and Wong (2017)
# Revised: July 18th. 2017
################################################################################################

rm(list=ls())

robust.se <- function(model, cluster){
  require(sandwich)
  require(lmtest)
  M <- length(unique(cluster))
  N <- length(cluster)
  K <- model$rank
  dfc <- (M/(M - 1)) * ((N - 1)/(N - K))
  uj <- apply(estfun(model), 2, function(x) tapply(x, cluster, sum));
  rcse.cov <- dfc * sandwich(model, meat = crossprod(uj)/N)
  rcse.se <- coeftest(model, rcse.cov)
  return(list(rcse.cov, rcse.se))
}

require(foreign)
require(readstata13)
require(glmnet)
require(ggplot2)
require(psych)
require(mediation)
require(stargazer)
require(treatSens)
require(plm)

########################################################## Graphs ######################################################################
d.data <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/Wang_Wong_2017_Graphs.csv")
d.placebo.data <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/Wang_Wong_2017_Graphs_Placebo.csv")
HKdata <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/Wang_Wong_2017_Main.csv")
placebo.data <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/Wang_Wong_2017_Placebo.csv")
ABS.data <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/Wang_Wong_2017_Mechanisms.csv")
protesters.data <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/Wang_Wong_2017_Protesters.csv")
HKdata <- HKdata[,-1]
placebo.data <- placebo.data[,-1]

theme_update(plot.title = element_text(hjust = 0.5))
p1 <- ggplot(d.data, aes(x = traveltime, y = delta_super_pan_share)) + geom_point(color = "grey40") + geom_smooth(color = "red") + 
  ylab("Diff. in vote share (opposition)") + xlab("Driving time (in minutes)") + labs(title = "Super-seats election") + 
  theme(text = element_text(size=20)) 
p1
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/super_pan_share.pdf", device = "pdf", height = 6, width = 8)

p2 <- ggplot(d.data, aes(x = hkdist, y = delta_super_pan_share)) + geom_point(color = "grey40") + geom_smooth(color = "red") + 
  ylab("Diff. in vote share (opposition)") + xlab("Straight-line distance (in kilometers)") + labs(title = "Super-seat election") + 
  theme(text = element_text(size=20)) 
p2
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/super_pan_share_dist.pdf", device = "pdf", height = 6, width = 8)

p3 <- ggplot(d.data, aes(x = traveltime, y = delta_antigov_share)) + geom_point(color = "grey40") + geom_smooth(color = "red") + 
  ylab("Diff. in vote share (opposition)") + xlab("Driving time (in minutes)") + labs(title = "Regular-seat election") + 
  theme(text = element_text(size=20)) 
p3
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/antigov_share.pdf", device = "pdf", height = 6, width = 8)

p4 <- ggplot(d.data, aes(x = hkdist, y = delta_antigov_share)) + geom_point(color = "grey40") + geom_smooth(color = "red") + 
  ylab("Diff. in vote share (opposition)") + xlab("Straight-line distance (in kilometers)") + labs(title = "Regular-seat election") + 
  theme(text = element_text(size=20)) 
p4
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/antigov_share_dist.pdf", device = "pdf", height = 6, width = 8)

p5 <- ggplot(d.data, aes(x = traveltime, y = delta_pan_share)) + geom_point(color = "grey40") + geom_smooth(color = "red") + 
  ylab("Diff. in Vote Share (pan-dem.)") + xlab("Driving time (in minutes)") + labs(title = "Regular-seat election") + 
  theme(text = element_text(size=20)) 
p5
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/pan_share.pdf", device = "pdf", height = 6, width = 8)

p6 <- ggplot(d.data, aes(x = traveltime, y = delta_local_share)) + geom_point(color = "grey40") + geom_smooth(color = "red") + 
  ylab("Diff. in vote share (localist)") + xlab("Driving time (in minutes)") + labs(title = "Regular-seat election") + 
  theme(text = element_text(size=20)) 
p6
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/local_share.pdf", device = "pdf", height = 6, width = 8)

p7 <- ggplot(d.data, aes(x = traveltime, y = super_pan_share12)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Vote share for the opposition (2012)") + xlab("Driving time (in minutes)") + labs(title = "Super-seat election") + 
  theme(text = element_text(size=20)) 
p7
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/super_pan_share_12_lm.pdf", device = "pdf", height = 6, width = 8)

p8 <- ggplot(d.data, aes(x = traveltime, y = super_pan_share16)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Vote share for the opposition (2016)") + xlab("Driving time (in minutes)") + labs(title = "Super-seat election") + 
  theme(text = element_text(size=20)) 
p8
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/super_pan_share_16_lm.pdf", device = "pdf", height = 6, width = 8)

p9 <- ggplot(d.data, aes(x = traveltime, y = antigov_share12)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Vote share for the opposition (2012)") + xlab("Driving time (in minutes)") + labs(title = "Regular-seat election") + 
  theme(text = element_text(size=20)) 
p9
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/antigov_share_12_lm.pdf", device = "pdf", height = 6, width = 8)

p10 <- ggplot(d.data, aes(x = traveltime, y = antigov_share16)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Vote share for the opposition (2016)") + xlab("Driving time (in minutes)") + labs(title = "Regular-seat election") + 
  theme(text = element_text(size=20)) 
p10
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/antigov_share_16_lm.pdf", device = "pdf", height = 6, width = 8)

p11 <- ggplot(d.placebo.data, aes(x = traveltime, y = antigov_share08)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Vote share for the opposition (2008)") + xlab("Driving time (in minutes)") + labs(title = "Regular-seat election") + 
  theme(text = element_text(size=20)) 
p11
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/antigov_share_08_lm.pdf", device = "pdf", height = 6, width = 8)

# # Figure A4
# X <- names(HKdata)[c(2,4:7,10,15,29:30)]
# d.data1 <- data.frame(d.data, HKdata[seq(2,802,2),X])
# sens.formula1 <- paste0("delta_super_pan_share", "~", "traveltime", "+", paste0(X, collapse = "+"))
# sens.formula2 <- paste0("delta_antigov_share", "~", "traveltime", "+", paste0(X[-8], collapse = "+"))
# sens1 <- treatSens(as.formula(sens.formula1), data = d.data1)
# sens2 <- treatSens(as.formula(sens.formula2), data = d.data1)
# sensPlot(sens1)
# sensPlot(sens2)

# Figure A3
migration.data <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/Wang_Wong_2017_migration.csv")
migration.data.plot <- migration.data[seq(2, 794, 2), ] 
migration.data.plot$delta_migration_ratio <- migration.data[seq(2, 794, 2), "real_ratio_migration"] - migration.data[seq(1, 793, 2), "real_ratio_migration"]  
m_p1 <- ggplot(migration.data.plot, aes(x = traveltime, y = delta_migration_ratio)) + geom_point(color = "grey40") + geom_smooth(color = "red") + 
  ylab("Diff. in emigration ratio") + xlab("Driving time (in minutes)") + labs(title = "Change in emigration ratio bw. 2012 and 2016") + 
  theme(text = element_text(size=20)) 
m_p1
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/change_migration.pdf", device = "pdf", height = 6, width = 8)

m_p2 <- ggplot(migration.data.plot, aes(x = traveltime, y = real_ratio_migration)) + geom_point(color = "grey40") + geom_smooth(color = "red") + 
  ylab("Emigration ratio in 2016") + xlab("Driving time (in minutes)") + labs(title = "Emigration ratio in 2016") + 
  theme(text = element_text(size=20)) 
m_p2
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/2016_migration.pdf", device = "pdf", height = 6, width = 8)

# Figure A5
protesters.design <- svydesign(id=~1, weights=~weight, data=protesters.data)
mean.traveltime <- svyby(~traveltime, ~movementparti, protesters.design, svymean)
ttest.traveltime <- svyttest(traveltime~movementparti, protesters.design)
se.traveltime <- ttest.traveltime$estimate / ttest.traveltime$statistic
graph.traveltime <- as.vector(c(ttest.traveltime$statistic, 
                                ttest.traveltime$conf.int / se.traveltime,
                                confint(ttest.traveltime, level = 0.9) / se.traveltime))
mean.edu <- svyby(~edu, ~movementparti, protesters.design, svymean)
ttest.edu <- svyttest(edu~movementparti, protesters.design)
se.edu <- ttest.edu$estimate / ttest.edu$statistic
graph.edu <- as.vector(c(ttest.edu$statistic, 
                         ttest.edu$conf.int / se.edu,
                         confint(ttest.edu, level = 0.9) / se.edu))
mean.age <- svyby(~age, ~movementparti, protesters.design, svymean)
ttest.age <- svyttest(age~movementparti, protesters.design)
se.age <- ttest.age$estimate / ttest.age$statistic
graph.age <- as.vector(c(ttest.age$statistic, 
                         ttest.age$conf.int / se.age,
                         confint(ttest.age, level = 0.9) / se.age))
mean.income <- svyby(~income, ~movementparti, protesters.design, svymean)
ttest.income <- svyttest(income~movementparti, protesters.design)
se.income <- ttest.income$estimate / ttest.income$statistic
graph.income <- as.vector(c(ttest.income$statistic, 
                            ttest.income$conf.int / se.income,
                            confint(ttest.income, level = 0.9) / se.income))
mean.gender <- svyby(~gender, ~movementparti, protesters.design, svymean)
ttest.gender <- svyttest(gender~movementparti, protesters.design)
se.gender <- ttest.gender$estimate / ttest.gender$statistic
graph.gender <- as.vector(c(ttest.gender$statistic, 
                            ttest.gender$conf.int / se.gender,
                            confint(ttest.gender, level = 0.9) / se.gender))
mean.contact <- svyby(~contact, ~movementparti, protesters.design, svymean)
ttest.contact <- svyttest(contact~movementparti, protesters.design)
se.contact <- ttest.contact$estimate / ttest.contact$statistic
graph.contact <- as.vector(c(ttest.contact$statistic, 
                             ttest.contact$conf.int / se.contact,
                             confint(ttest.contact, level = 0.9) / se.contact))

ABS.graph.data <- data.frame(rbind(graph.traveltime, graph.gender, graph.age, graph.edu, graph.income, graph.contact))
names(ABS.graph.data) <- c("coef", "CI.lower95", "CI.upper95", "CI.lower90", "CI.upper90")
ABS.graph.data$names <- c("Travel time", "Gender", "Age", "Education", "Income", "Contact")
ABS.graph.data$names <- factor(ABS.graph.data$names, levels = rev(ABS.graph.data$names))
ABS.graph.data$coef <- round(ABS.graph.data$coef, 3)
ABS.graph.data$CI.lower95 <- round(ABS.graph.data$CI.lower95, 3)
ABS.graph.data$CI.upper95 <- round(ABS.graph.data$CI.upper95, 3)
ABS.graph.data$CI.lower90 <- round(ABS.graph.data$CI.lower90, 3)
ABS.graph.data$CI.upper90 <- round(ABS.graph.data$CI.upper90, 3)

p <- ggplot(ABS.graph.data) + 
  geom_pointrange(aes(x=names, y=coef, ymin=CI.lower95, ymax=CI.upper95), colour="red", size = 0.3, lty = 2) + 
  geom_errorbar(aes(x=names, ymin=CI.lower90, ymax=CI.upper90), colour="red", size = 0.3) + theme_bw() + 
  coord_flip() + geom_hline(aes(yintercept = 0), colour = "black", lty=2) + xlab('Variable (protesters)') + ylab('') + 
  theme(text = element_text(size=20)) 
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/protester_comparison.pdf", device = "pdf", height = 6, width = 8)

# Figure A6
ABS.Y <- c("dem.pca", "eff.pca", "econ.pca", "income")
ABS.data.dem <- ABS.data[complete.cases(ABS.data[,ABS.Y[1]]),]
ABS.data.eff <- ABS.data[complete.cases(ABS.data[,ABS.Y[2]]),]
ABS.data.econ <- ABS.data[complete.cases(ABS.data[,ABS.Y[4]]),]
ABS.data.rinc <- ABS.data[complete.cases(ABS.data[,ABS.Y[4]]),]

dem.pca.mean.post <- aggregate(dem.pca~district, ABS.data.dem[ABS.data.dem$post_umbrella==1,], mean)[,2]
eff.pca.mean.post <- aggregate(eff.pca~district, ABS.data.eff[ABS.data.eff$post_umbrella==1,], mean)[,2]
econ.pca.mean.post <- aggregate(econ.pca~district, ABS.data.econ[ABS.data.econ$post_umbrella==1,], mean)[,2]
rinc.pca.mean.post <- aggregate(income~district, ABS.data.rinc[ABS.data.rinc$post_umbrella==1,], mean)[,2]
dem.pca.mean.pre <- aggregate(dem.pca~district, ABS.data.dem[ABS.data.dem$post_umbrella==0,], mean)[,2]
eff.pca.mean.pre <- aggregate(eff.pca~district, ABS.data.eff[ABS.data.eff$post_umbrella==0,], mean)[,2]
econ.pca.mean.pre <- aggregate(econ.pca~district, ABS.data.econ[ABS.data.econ$post_umbrella==0,], mean)[,2]
rinc.pca.mean.pre <- aggregate(income~district, ABS.data.rinc[ABS.data.rinc$post_umbrella==0,], mean)[,2]

dem.pca.mean <- dem.pca.mean.post - dem.pca.mean.pre
eff.pca.mean <- eff.pca.mean.post - eff.pca.mean.pre
econ.pca.mean <- econ.pca.mean.post - econ.pca.mean.pre
rinc.pca.mean <- rinc.pca.mean.post - rinc.pca.mean.pre

traveltime.mean <- aggregate(traveltime~district, ABS.data, mean)[,2]
district <- unique(ABS.data$region_id)
ABS.plot <- data.frame(dem.pca.mean, eff.pca.mean, econ.pca.mean, rinc.pca.mean, traveltime.mean, district)
names(ABS.plot) <- c("dem", "eff", "econ", "rinc", "traveltime", "district")

ABS.plot$econ.norm <- (ABS.plot$econ - mean(ABS.plot$econ))/sd(ABS.plot$econ)

p1 <- ggplot(ABS.plot) + geom_smooth(aes(x = traveltime, y = dem), color = "red", span = 1) +
  ylab("Approval for democracy (PCA)") + xlab("Driving time (in minutes)") +
  geom_text(aes(28, 0, label = "Approval for democracy", vjust = -1), color = "black", size = 8) + 
  theme(text = element_text(size=20)) 
p1
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/dem_pca.pdf", device = "pdf", height = 6, width = 8)

p2 <- ggplot(ABS.plot) + geom_smooth(aes(x = traveltime, y = eff), color = "red", span = 1) +
  ylab("Political efficacy (PCA)") + xlab("Driving time (in minutes)") + 
  geom_text(aes(28, 0.5, label = "Political efficacy", vjust = -1), color = "black", size = 8) + 
  theme(text = element_text(size=20)) 
p2
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/eff_pca.pdf", device = "pdf", height = 6, width = 8)

p3 <- ggplot(ABS.plot) + geom_smooth(aes(x = traveltime, y = econ), color = "blue", span = 1) +
  ylab("Economic insecurity (PCA)") + xlab("Driving time (in minutes)") + 
  geom_text(aes(28, 0.1, label = "Economic insecurity", vjust = -1), color = "black", size = 8) + 
  theme(text = element_text(size=20)) 
p3
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/econ_pca.pdf", device = "pdf", height = 6, width = 8)

p4 <- ggplot(ABS.plot) + geom_smooth(aes(x = traveltime, y = rinc), color = "green", span = 1) +
  ylab("Real income") + xlab("Driving time (in minutes)") + 
  geom_text(aes(30, 0.3, label = "Real income", vjust = -1), color = "black", size = 8) + 
  theme(text = element_text(size=20)) 
p4
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/rinc_pca.pdf", device = "pdf", height = 6, width = 8)


# Figure A8
HKES.data <- read.dta13("~/Dropbox/CurrentProjects/HKElection/WorkingData/HKElectionSurvey.dta", convert.factors = FALSE)
HKES.data <- HKES.data[!is.na(HKES.data[, "weight_match"]) , ]
att.data <- rbind(as.matrix(cbind(HKES.data[HKES.data$Q52 < 11, c("traveltime", "Q52", "wgtpost")], rep("red", nrow(HKES.data[HKES.data$Q52 < 11, ])))), 
                  as.matrix(cbind(HKES.data[HKES.data$Q53 < 11, c("traveltime", "Q53", "wgtpost")], rep("blue", nrow(HKES.data[HKES.data$Q53 < 11, ])))), 
                  as.matrix(cbind(HKES.data[HKES.data$Q54 < 11, c("traveltime", "Q54", "wgtpost")], rep("green", nrow(HKES.data[HKES.data$Q54 < 11, ])))))
att.data <- data.frame(att.data)
names(att.data) <- c("distance", "attitude", "weight", "color")
theme_update(plot.title = element_text(hjust = 0.5))
att.p1 <- ggplot() + geom_smooth(aes(x = traveltime, y = Q52, weight = wgtpost, color = "red"), HKES.data[HKES.data$Q52 < 11, ], method = "lm") + 
  geom_smooth(aes(x = traveltime, y = Q53, weight = wgtpost, color = "blue"), HKES.data[HKES.data$Q53 < 11, ], method = "lm") + 
  geom_smooth(aes(x = traveltime, y = Q54, weight = wgtpost, color = "green"), HKES.data[HKES.data$Q54 < 11, ], method = "lm") + 
  ylab("Attitude toward politicians (2016)") + xlab("Driving time (in minutes)") +
  scale_colour_manual(name = 'Camps', values =c("blue"="blue", "red"="red", "green"="green"), labels = c("Pan-dem", "Localist", "Pro-Beijing")) + 
  theme(text = element_text(size=20)) 
att.p1
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/attitude.pdf", device = "pdf", height = 6, width = 8)


# dist_super_opposition_share_pre <- aggregate(super_pan_share~district, data = HKdata[HKdata$post_umbrella==0,], mean)
# names(dist_super_opposition_share_pre)[2] <- "super_opposition_share_pre"
# dist_super_opposition_share_post <- aggregate(super_pan_share~district, data = HKdata[HKdata$post_umbrella==1,], mean)
# names(dist_super_opposition_share_post)[2] <- "super_opposition_share_post"
# dist_regular_opposition_share_pre <- aggregate(pan_share~district, data = HKdata[HKdata$post_umbrella==0,], mean)
# names(dist_regular_opposition_share_pre)[2] <- "regular_opposition_share_pre"
# dist_regular_opposition_share_post <- aggregate(pan_share~district, data = HKdata[HKdata$post_umbrella==1,], mean)
# names(dist_regular_opposition_share_post)[2] <- "regular_opposition_share_post"
# 
# ABS.plot1 <- data.frame(econ.pca.mean.post, econ.pca.mean.pre, rinc.pca.mean.post, rinc.pca.mean.pre, district, traveltime.mean)
# ABS.plot1 <- merge(ABS.plot1, dist_super_opposition_share_pre, by.x = "district", by.y = "district")
# ABS.plot1 <- merge(ABS.plot1, dist_super_opposition_share_post, by.x = "district", by.y = "district")
# ABS.plot1 <- merge(ABS.plot1, dist_regular_opposition_share_pre, by.x = "district", by.y = "district")
# ABS.plot1 <- merge(ABS.plot1, dist_regular_opposition_share_post, by.x = "district", by.y = "district")
# 
# p7 <- ggplot(ABS.plot1) + geom_smooth(aes(x = econ.pca.mean.pre, y = super_opposition_share_pre), color = "green") +
#   ylab("Vote Share for the Opposition (2012)") + xlab("Socio-economic Risks (PCA)")
# p7
# 
# p8 <- ggplot(ABS.plot1) + geom_smooth(aes(x = econ.pca.mean.post, y = super_opposition_share_post), color = "green") +
#   ylab("Vote Share for the Opposition (2016)") + xlab("Socio-economic Risks (PCA)")
# p8
########################################################## Tables ######################################################################

map.data.public <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/map.data.public.csv")
HKdata.public <- merge(HKdata, map.data.public, by.x = "ccode", by.y = "ccode")
HKdata.public$cross.public <- HKdata.public$travel.time.public * HKdata.public$post_umbrella

Y1 <- "super_pan_share"
Y2 <- "antigov_share"
Y3 <- "pan_share"
Y4 <- "local_share"
Y5 <- "super_weighted_ideology1"
Y6 <- "weighted_ideology1"
Y7 <- "turnout_rate"
l.Y2 <- "lantigov_share"

Y_all <- c(Y1, Y2, Y3, Y4, Y5, Y6, Y7)
D <- "cross"
D1 <- "cross1"
D.pub <- "cross.public"
D.fake <- "cross_fake"
D1.fake <- "cross1_fake"
Key <- "traveltime"
Key1 <- "hkdist"
X.district <- c("midincome", "rentoverincome")
X <- names(HKdata)[c(2,4:7,10,13:15,29:30)]
X.interaction <- names(HKdata)[c(72:81)]
X.all <- names(HKdata)[c(2:30,33:37)]
X.interaction.all <- names(HKdata)[c(72:81,87:105, 108:112)]
unit <- "ccode"
period <- "post_umbrella"
FE <- c(unit, period)
cl <- "ccode"

# Table A1
HK.formula1 <- paste0(Y1, "~", D, "+", "factor(", unit, ")", "+ factor(", period, ")")
HK.formula2 <- paste0(Y2, "~", D, "+", "factor(", unit, ")", "+ factor(", period, ")")
HK.formula3 <- paste0(Y1, "~", D, "+", "factor(", period, ")")
HK.formula4 <- paste0(Y2, "~", D, "+", "factor(", period, ")")
HK.formula5 <- paste0(Y1, "~", D.pub, "+", "factor(", period, ")")
HK.formula6 <- paste0(Y2, "~", D.pub, "+", "factor(", period, ")")
HK.result1 <- lm(as.formula(HK.formula1), HKdata, weights = voter_num)
HK.result2 <- lm(as.formula(HK.formula2), HKdata, weights = voter_num)
HK.result3 <- plm(as.formula(HK.formula3), HKdata[HKdata$unmatched == 0,], index = unit)
HK.result4 <- plm(as.formula(HK.formula4), HKdata[HKdata$unmatched == 0,], index = unit)
HK.result5 <- plm(as.formula(HK.formula5), HKdata.public, index = unit)
HK.result6 <- plm(as.formula(HK.formula6), HKdata.public, index = unit)
HK.robust1 <- robust.se(HK.result1, HKdata[, cl])
HK.robust2 <- robust.se(HK.result2, HKdata[, cl])
HK.robust3 <- coeftest(HK.result3, vcov = vcovHC(HK.result3, type = "HC0", cluster = "group"))
HK.robust4 <- coeftest(HK.result4, vcov = vcovHC(HK.result4, type = "HC0", cluster = "group"))
HK.robust5 <- coeftest(HK.result5, vcov = vcovHC(HK.result5, type = "HC0", cluster = "group"))
HK.robust6 <- coeftest(HK.result6, vcov = vcovHC(HK.result6, type = "HC0", cluster = "group"))


HK.formula7 <- paste0(Y2, "~", l.Y2, "+", D, "+", "factor(", period, ")")
HK.result7 <- plm(as.formula(HK.formula7), placebo.data, index = unit)
HK.robust7 <- coeftest(HK.result7, vcov = vcovHC(HK.result7, type = "HC0", cluster = "group"))

stargazer(HK.robust1[[2]], HK.robust3, HK.robust5, HK.robust2[[2]], HK.robust4, HK.robust6, HK.robust7, 
          covariate.labels = c("Lagged vote share", "Driving time * Post Umbrella", "Commuting time * Post Umbrella", "Post Umbrella"), 
          star.cutoffs = c(0.05, 0.01, 0.001),
          digits = 3, keep = c("cross", "cross1", "lantigov_share", "post_umbrella"),
          title = "Table A1: Robustness of Main Results", no.space = T)


# Table A2
Cov.formula1 <- paste0(Y1, "~", D, "+", paste0(X.interaction, collapse = "+"), "+", "factor(", period, ")")
Cov.formula2 <- paste0(Y2, "~", D, "+", paste0(X.interaction, collapse = "+"), "+", "factor(", period, ")")
Cov.formula3 <- paste0(Y1, "~", D, "+", paste0(X.district, collapse = "+"), "+", "factor(", period, ")")
Cov.formula4 <- paste0(Y2, "~", D, "+", paste0(X.district, collapse = "+"), "+", "factor(", period, ")")
Cov.result1 <- plm(as.formula(Cov.formula1), HKdata, index = unit)
Cov.result2 <- plm(as.formula(Cov.formula2), HKdata, index = unit)
Cov.result3 <- plm(as.formula(Cov.formula3), HKdata, index = unit)
Cov.result4 <- plm(as.formula(Cov.formula4), HKdata, index = unit)
Cov.robust1 <- coeftest(Cov.result1, vcov = vcovHC(Cov.result1, type = "HC0", cluster = "group"))
Cov.robust2 <- coeftest(Cov.result2, vcov = vcovHC(Cov.result2, type = "HC0", cluster = "group"))
Cov.robust3 <- coeftest(Cov.result3, vcov = vcovHC(Cov.result3, type = "HC0", cluster = "group"))
Cov.robust4 <- coeftest(Cov.result4, vcov = vcovHC(Cov.result4, type = "HC0", cluster = "group"))


lasso.X <- scale(as.matrix(HKdata[seq(2,802,2),c(Key, X.all)]))
lasso.Y1 <- scale(HKdata[seq(2,802,2),Y1] - HKdata[seq(1,802,2),Y1])
lasso.Y2 <- scale(HKdata[seq(2,802,2),Y2] - HKdata[seq(1,802,2),Y2])

lasso.out1 <- cv.glmnet(lasso.X, lasso.Y1, alpha = 1, family = "gaussian")
cv.lasso.Y1 <- cv.glmnet(lasso.X, lasso.Y1, family = "gaussian", alpha = 1)
lasso.coef1 <- coef(cv.lasso.Y1)

lasso.out2 <- cv.glmnet(lasso.X, lasso.Y2, alpha = 1, family = "gaussian")
cv.lasso.Y2 <- cv.glmnet(lasso.X, lasso.Y2, family = "gaussian", alpha = 1)
lasso.coef2 <- coef(cv.lasso.Y2)

lasso.formula1 <- paste0(Y1, "~", D, "+", paste0(X.interaction.all[c(4,20,27,28)], collapse = "+"), "+", "factor(", period, ")")
lasso.formula2 <- paste0(Y2, "~", D, "+", paste0(X.interaction.all[c(3,8,11,30,31)], collapse = "+"), "+", "factor(", period, ")")
lasso.result1 <- plm(as.formula(lasso.formula1), HKdata, index = unit)
lasso.result2 <- plm(as.formula(lasso.formula2), HKdata, index = unit)
lasso.robust1 <- coeftest(lasso.result1, vcov = vcovHC(lasso.result1, type = "HC0", cluster = "group"))
lasso.robust2 <- coeftest(lasso.result2, vcov = vcovHC(lasso.result2, type = "HC0", cluster = "group"))

stargazer(Cov.robust1, Cov.robust3, lasso.robust1, Cov.robust2, Cov.robust4, lasso.robust2, 
          covariate.labels = c("Driving time * Post Umbrella"), 
          digits = 3, keep = c("cross", "post_umbrella", "midincome", "rentoverincome"), star.cutoffs = c(0.05, 0.01, 0.001),
          title = "Table A2: Results with Covariates", no.space = T)

# Table A3
mediation.formula1 <- paste0(Y7, "~", D, "+", "factor(", unit, ") + factor(", period, ")")
direct.formula1 <- paste0(Y1, "~", D, "+", Y7, "+", "factor(", unit, ") + factor(", period, ")")
direct.formula1a <- paste0(Y1, "~", Y7, "+", "factor(", unit, ") + factor(", period, ")")
mediation.formula2 <- paste0(Y7, "~", D, "+", "factor(", unit, ") + factor(", period, ")")
direct.formula2 <- paste0(Y2, "~", D, "+", Y7, "+", "factor(", unit, ") + factor(", period, ")")
direct.formula2a <- paste0(Y2, "~", Y7, "+", "factor(", unit, ") + factor(", period, ")")
mediation_turnout_super <- lm(as.formula(mediation.formula1), data = HKdata)
direct_turnout_super <- lm(as.formula(direct.formula1), data = HKdata)
mediation_turnout_regular <- lm(as.formula(mediation.formula2), data = HKdata)
direct_turnout_regular <- lm(as.formula(direct.formula2), data = HKdata)

mediation.result1 <- mediate(mediation_turnout_super, direct_turnout_super, 
                             sims=50, treat="cross", mediator="turnout_rate", robustSE = T)
mediation.result2 <- mediate(mediation_turnout_regular, direct_turnout_regular, 
                             sims=50, treat="cross", mediator="turnout_rate", robustSE = T)


# Table A4
TST.data <- d.data[(d.data[, "ccode"] == "A01" | d.data[, "ccode"] == "B03" | d.data[, "ccode"] == "B04" | 
                      d.data[, "ccode"] == "E04" | d.data[, "ccode"] == "E06" | d.data[, "ccode"] == "E13" | 
                      d.data[, "ccode"] == "E15" | d.data[, "ccode"] == "E01" | d.data[, "ccode"] == "E02" | d.data[, "ccode"] == "E17"), c(X, "ccode", "trade_share")]
TST.data$psudo <- 0
TST.data[TST.data[, "ccode"] == "E01" | TST.data[, "ccode"] == "E02" | TST.data[, "ccode"] == "E17", "psudo"] <- 1
TST.compare <- apply(TST.data[-c(4, 5, 6), c(1:9,11)], 2, mean)
TST.psuedo <- apply(TST.data[c(4, 5, 6), c(1:9,11)], 2, mean)

# Table A5, A6 and A7
ABS.Y <- c("demobestgov", "demoscalefuture", "demosuit", "demovalue1", "demovalue3", "selfpoliticsno1", "selfpoliticsno2",
           "selfpoliticsyes", "econtoday", "econpast", "incomesatisfy", "dem.pca", "eff.pca", "econ.pca", "income")
ABS.X <- c("post_umbrella", "gender", "age", "age2", "married", "college")
ABS.D <- "cross1"
ABS.cl <- "district"
ABS.result1 <- list()
ABS.robust1 <- list()
ABS.result2 <- list()
ABS.robust2 <- list()

for (i in 1:length(ABS.Y)){
  ABS.data.i <- ABS.data[complete.cases(ABS.data[,ABS.Y[i]]),]
  ABS.formula1 <- paste0(ABS.Y[i], "~", ABS.D, "+", paste0(ABS.X, collapse = "+"))
  ABS.formula2 <- paste0(ABS.Y[i], "~", paste0(ABS.X, collapse = "+"))
  ABS.result1[[i]] <- plm(as.formula(ABS.formula1), data = ABS.data.i, index = ABS.cl)
  ABS.result2[[i]] <- plm(as.formula(ABS.formula2), data = ABS.data.i, index = ABS.cl)
  ABS.robust1[[i]] <- coeftest(ABS.result1[[i]], vcov = vcovHC(ABS.result1[[i]], type = "HC0", cluster = "group"))
  ABS.robust2[[i]] <- coeftest(ABS.result2[[i]], vcov = vcovHC(ABS.result2[[i]], type = "HC0", cluster = "group"))
}

stargazer(ABS.robust1[[1]], ABS.robust2[[1]], ABS.robust1[[2]], ABS.robust2[[2]], ABS.robust1[[3]], ABS.robust2[[3]],
          covariate.labels = c("Driving time * Post Umbrella", "Post Umbrella", "Gender", "Age", "Age Squared", "Married", "College"), 
          digits = 3, keep = c("cross1", "post_umbrella", "gender", "age", "age2", "married", "college"), star.cutoffs = c(0.05, 0.01, 0.001),
          title = "Table A4: Mechanisms (Approval for Democracy)", no.space = T)
stargazer(ABS.robust1[[4]], ABS.robust2[[4]], ABS.robust1[[5]], ABS.robust2[[5]], ABS.robust1[[12]], ABS.robust2[[12]],
          covariate.labels = c("Driving time * Post Umbrella", "Post Umbrella", "Gender", "Age", "Age Squared", "Married", "College"), 
          digits = 3, keep = c("cross1", "post_umbrella", "gender", "age", "age2", "married", "college"), star.cutoffs = c(0.05, 0.01, 0.001),
          title = "Table A4: Mechanisms (Approval for Democracy)", no.space = T)
stargazer(ABS.robust1[[6]], ABS.robust2[[6]], ABS.robust1[[7]], ABS.robust2[[7]], 
          ABS.robust1[[8]], ABS.robust2[[8]], ABS.robust1[[13]], ABS.robust2[[13]],
          covariate.labels = c("Driving time * Post Umbrella", "Post Umbrella", "Gender", "Age", "Age Squared", "Married", "Collage"), 
          digits = 3, keep = c("cross1", "post_umbrella", "gender", "age", "age2", "married", "college"), star.cutoffs = c(0.05, 0.01, 0.001),
          title = "Table A5: Mechanisms (Political Efficacy)", no.space = T)
stargazer(ABS.robust1[[9]], ABS.robust2[[9]], ABS.robust1[[10]], ABS.robust2[[10]], 
          ABS.robust1[[11]], ABS.robust2[[11]], ABS.robust1[[14]], ABS.robust2[[14]], 
          ABS.robust1[[15]], ABS.robust2[[15]],
          covariate.labels = c("Driving time * Post Umbrella", "Post Umbrella", "Gender", "Age", "Age Squared", "Married", "Collage"), 
          digits = 3, keep = c("cross1", "post_umbrella", "gender", "age", "age2", "married", "college"), star.cutoffs = c(0.05, 0.01, 0.001),
          title = "Table A6: Mechanisms (Socio-economic Risks)", no.space = T)


# Table A9
HKES.data$vote12 <- NA
HKES.data$vote16 <- NA
HKES.data[HKES.data$vote_pandem12 == 1, ]$vote12 <- 0
HKES.data[HKES.data$vote_gov12 == 1, ]$vote12 <- -1
HKES.data[HKES.data$vote_pandem == 1, ]$vote16 <- 0
HKES.data[HKES.data$vote_gov == 1, ]$vote16 <- -1
HKES.data[HKES.data$vote_local == 1, ]$vote16 <- 1
HKES.data2 <- HKES.data[!is.na(HKES.data[, "vote12"]) & !is.na(HKES.data[, "vote16"]), ]
conversion.matrix <- matrix(0, 3, 4)
conversion.matrix[1, 1] <- dim(HKES.data2[HKES.data2$vote12 == -1 & HKES.data2$vote16 == -1,])[1]
conversion.matrix[1, 2] <- dim(HKES.data2[HKES.data2$vote12 == -1 & HKES.data2$vote16 == 0,])[1]
conversion.matrix[1, 3] <- dim(HKES.data2[HKES.data2$vote12 == -1 & HKES.data2$vote16 == 1,])[1]
conversion.matrix[1, 4] <- dim(HKES.data2[HKES.data2$vote12 == -1,])[1]
conversion.matrix[2, 1] <- dim(HKES.data2[HKES.data2$vote12 == 0 & HKES.data2$vote16 == -1,])[1]
conversion.matrix[2, 2] <- dim(HKES.data2[HKES.data2$vote12 == 0 & HKES.data2$vote16 == 0,])[1]
conversion.matrix[2, 3] <- dim(HKES.data2[HKES.data2$vote12 == 0 & HKES.data2$vote16 == 1,])[1]
conversion.matrix[2, 4] <- dim(HKES.data2[HKES.data2$vote12 == 0,])[1]
conversion.matrix[3, 1] <- dim(HKES.data2[HKES.data2$vote16 == -1,])[1]
conversion.matrix[3, 2] <- dim(HKES.data2[HKES.data2$vote16 == 0,])[1]
conversion.matrix[3, 3] <- dim(HKES.data2[HKES.data2$vote16 == 1,])[1]
conversion.matrix[3, 4] <- dim(HKES.data2)[1]

rownames(conversion.matrix) <- c("Pro-Beijing 2012", "Pan-Democratic 2012", "Total 2012")
colnames(conversion.matrix) <- c("Pro-Beijing 2016", "Pan-Democratic 2016", "Localist 2016", "Total 2016")
stargazer(conversion.matrix, summary = FALSE)