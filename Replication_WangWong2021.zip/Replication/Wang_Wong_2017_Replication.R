################################################################################################
# Program: Wang_Wong_2017_Replication.R
# Author:	Ye Wang & Stan Wong
# Data:	Wang_Wong_2017_Main.csv, Wang_Wong_2017_Placebo.csv, Wang_Wong_2017_Graphs.csv, Wang_Wong_2017_Graphs_Placebo.csv
# Aim: Generate tables and graphs in Wang and Wong (2017)
# Revised: July. 18th. 2017
################################################################################################

rm(list=ls())

# Cluster SE
robust.se <- function(model, cluster){
  require(sandwich)
  require(lmtest)
  M <- length(unique(cluster))
  N <- length(cluster)
  K <- model$rank
  dfc <- (M/(M - 1)) * ((N - 1)/(N - K))
  uj <- apply(estfun(model), 2, function(x) tapply(x, cluster, sum));
  rcse.cov <- dfc * sandwich(model, meat = crossprod(uj)/N)
  rcse.se <- coeftest(model, rcse.cov)
  return(list(rcse.cov, rcse.se))
}

# Cluster Bootstrapping SE
cluster.boot.se <- function(formula, data, Y, D, X, FE, cl, nboots = 1000){
  model <- plm(as.formula(formula), data = data, index = unit)
  boot.result <- matrix(0, (length(X) + 2), nboots)
  n <- dim(data)[1]
  unit <- FE[1]
  period <- FE[2]
  for (i in 1:nboots) { 
    clusters <- unique(data[,cl])
    id.list <- split(1:n, data[,cl])
    cluster.boot <- sample(clusters, length(clusters), replace = T)
    smp <- unlist(id.list[match(cluster.boot, clusters)])
    s <- data[smp,]
    if (is.null(X)){
      s <- s[complete.cases(s[,c(Y,D,FE)]),]
    } else {
      s <- s[complete.cases(s[,c(Y,D,X,FE)]),]
    }
    s[,unit] <- rep(1:length(cluster.boot), as.vector(lengths(id.list[match(cluster.boot, clusters)])))
    s <- s[order(s[,unit], s[,period]),]
    boot.result[, i] <- as.vector(coef(plm(as.formula(formula), data = s, index = unit)))
  }
  boot.CI.95 <- quantile(boot.result, c(0.025,0.975))
  boot.CI.99 <- quantile(boot.result, c(0.005,0.995))
  boot.CI.999 <- quantile(boot.result, c(0.0005,0.9995))
  boot.mean <- apply(boot.result, 1, mean)
  boot.VCOV <- matrix(0, 2, 2)
  for (i in 1:nboots){
    boot.VCOV <- boot.VCOV + (boot.result[, i] - boot.mean) %*% t(boot.result[, i] - boot.mean)
  }
  boot.VCOV <- boot.VCOV / nboots
  return(boot.VCOV)
}


require(foreign)
require(readstata13)
require(glmnet)
require(ggplot2)
require(psych)
require(mediation)
require(stargazer)
require(treatSens)
require(survey)
require(CBPS)
require(plm)
require(dplyr)
require(lfe)
require(clubSandwich)
source("/Users/yewang/Dropbox/CurrentProjects/HKElection/Code/conley-se-master/code/conley.R")


########################################################## Graphs ######################################################################
d.data <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/Wang_Wong_2017_Graphs.csv")

# Figure 2
theme_update(plot.title = element_text(hjust = 0.5))
p1 <- ggplot(d.data, aes(x = traveltime, y = delta_super_pan_share)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Diff. in vote share (opposition)") + xlab("Driving time (in minutes)") + labs(title = "Super-seat election") + 
  theme(text = element_text(size=20)) 
p1
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/super_pan_share_lm.pdf", device = "pdf", height = 6, width = 8)

p2 <- ggplot(d.data, aes(x = hkdist, y = delta_super_pan_share)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Diff. in vote share (opposition)") + xlab("Straight-line distance (in kilometers)") + labs(title = "Super-seat election") + 
  theme(text = element_text(size=20)) 
p2
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/super_pan_share_dist_lm.pdf", device = "pdf", height = 6, width = 8)

p3 <- ggplot(d.data, aes(x = traveltime, y = delta_antigov_share)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Diff. in vote share (opposition)") + xlab("Driving time (in minutes)") + labs(title = "Regular-seat election") + 
  theme(text = element_text(size=20)) 
p3
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/antigov_share_lm.pdf", device = "pdf", height = 6, width = 8)

p4 <- ggplot(d.data, aes(x = hkdist, y = delta_antigov_share)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Diff. in vote share (opposition)") + xlab("Straight-line distance (in kilometers)") + labs(title = "Regular-seat election") + 
  theme(text = element_text(size=20)) 
p4
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/antigov_share_dist_lm.pdf", device = "pdf", height = 6, width = 8)

p5 <- ggplot(d.data, aes(x = traveltime, y = delta_pan_share)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Diff. in vote share (pan-dem.)") + xlab("Driving time (in minutes)") + labs(title = "Regular-seat election") + 
  theme(text = element_text(size=20)) 
p5
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/pan_share_lm.pdf", device = "pdf", height = 6, width = 8)

p6 <- ggplot(d.data, aes(x = traveltime, y = delta_local_share)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Diff. in vote share (localist)") + xlab("Driving time (in minutes)") + labs(title = "Regular-seat election") + 
  theme(text = element_text(size=20)) 
p6
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/local_share_lm.pdf", device = "pdf", height = 6, width = 8)


# Figure 3
X.CBPS <- names(d.data)[c(18:27)]
CBPS.formula.score <- paste0("traveltime", "~", paste0(X.CBPS, collapse = "+"))
CBPS.fit.score <- CBPS(as.formula(CBPS.formula.score), data = d.data, method = "exact")
CBPS.scores <- CBPS.fit.score$weights
CBPS.formula1 <- paste0("delta_super_pan_share", "~", "traveltime")
CBPS.formula2 <- paste0("delta_antigov_share", "~", "traveltime")
CBPS.test.unweighted <- lm(as.formula(CBPS.formula.score), data = d.data)
CBPS.test.weighted <- lm(as.formula(CBPS.formula.score), data = d.data, weights = CBPS.scores)
CBPS.result.unweighted1 <- lm(as.formula(CBPS.formula1), data = d.data)
CBPS.result.weighted1 <- lm(as.formula(CBPS.formula1), data = d.data, weights = CBPS.scores)
CBPS.robust.unweighted1 <- robust.se(CBPS.result.unweighted1, d.data$ccode)
CBPS.robust.weighted1 <- robust.se(CBPS.result.weighted1, d.data$ccode)
CBPS.result.unweighted2 <- lm(as.formula(CBPS.formula2), data = d.data)
CBPS.result.weighted2 <- lm(as.formula(CBPS.formula2), data = d.data, weights = CBPS.scores)
CBPS.robust.unweighted2 <- robust.se(CBPS.result.unweighted2, d.data$ccode)
CBPS.robust.weighted2 <- robust.se(CBPS.result.weighted2, d.data$ccode)
CBPS.coefs.unweighted <- data.frame(rbind(c(coef(CBPS.result.unweighted1)[2]/coef(summary(CBPS.result.unweighted1))[2, "Std. Error"], 
                                            confint(CBPS.result.unweighted1)[2,]/coef(summary(CBPS.result.unweighted1))[2, "Std. Error"]),
                                          c(coef(CBPS.result.unweighted2)[2]/coef(summary(CBPS.result.unweighted2))[2, "Std. Error"], 
                                            confint(CBPS.result.unweighted2)[2,]/coef(summary(CBPS.result.unweighted2))[2, "Std. Error"]),
                                          cbind(coef(CBPS.test.unweighted)[-1]/coef(summary(CBPS.test.unweighted))[-1, "Std. Error"],
                                                confint(CBPS.test.unweighted)[-1,]/coef(summary(CBPS.test.unweighted))[-1, "Std. Error"])))
names(CBPS.coefs.unweighted) <- c("coef", "CI.lower95", "CI.upper95")
CBPS.coefs.unweighted$names <- c("Driving time (Super seats)", "Driving time (Regular seats)", "Chinese share", "Male share", "Young share",
                                 "Old share", "Married share", "College share", "Trade share",
                                 "Finance share", "Rich share", "Poor share")

CBPS.coefs.weighted <- data.frame(rbind(c(coef(CBPS.result.weighted1)[2]/coef(summary(CBPS.result.weighted1))[2, "Std. Error"], 
                                          confint(CBPS.result.weighted1)[2,]/coef(summary(CBPS.result.weighted1))[2, "Std. Error"]),
                                        c(coef(CBPS.result.weighted2)[2]/coef(summary(CBPS.result.weighted2))[2, "Std. Error"], 
                                          confint(CBPS.result.weighted2)[2,]/coef(summary(CBPS.result.weighted2))[2, "Std. Error"]),
                                        cbind(coef(CBPS.test.weighted)[-1]/coef(summary(CBPS.test.weighted))[-1, "Std. Error"], 
                                              confint(CBPS.test.weighted)[-1,]/coef(summary(CBPS.test.weighted))[-1, "Std. Error"])))
names(CBPS.coefs.weighted) <- c("coef", "CI.lower95", "CI.upper95")
CBPS.coefs.weighted$names <- c("Driving time (Super-seat)", "Driving time (Regular-seat)", "Mandarin share", "Male share", "Young share",
                               "Old share", "Married share", "College share", "Trade share",
                               "Finance share", "Rich share", "Poor share")

CBPS.coefs.unweighted$names <- factor(CBPS.coefs.unweighted$names, levels = rev(CBPS.coefs.unweighted$names))
CBPS.coefs.weighted$names <- factor(CBPS.coefs.weighted$names, levels = rev(CBPS.coefs.weighted$names))

colors1 <- c("red", "red", rep("black", 10))
colors2 <- c("red", "red", rep("black", 10))

CBPS.coefs.unweighted_p <- ggplot(CBPS.coefs.unweighted) + 
  geom_pointrange(aes(x=names, y=coef, ymin=CI.lower95, ymax=CI.upper95), colour=colors1, size = 0.3) + 
  theme_bw() + coord_flip() + geom_hline(aes(yintercept = 0), colour = "black", lty=2) + xlab('') + ylab('') + 
  theme(text = element_text(size=20)) 
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/CBPS_unweighted.pdf", device = "pdf", height = 6, width = 8)

CBPS.coefs.weighted_p <- ggplot(CBPS.coefs.weighted) + 
  geom_pointrange(aes(x=names, y=coef, ymin=CI.lower95, ymax=CI.upper95), colour=colors2, size = 0.3) + 
  theme_bw() + coord_flip() + geom_hline(aes(yintercept = 0), colour = "black", lty=2) + xlab('') + ylab('') + 
  theme(text = element_text(size=20)) 
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/CBPS_weighted.pdf", device = "pdf", height = 6, width = 8)


# Figure 4
d.placebo.data <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/Wang_Wong_2017_Graphs_Placebo.csv")
p7 <- ggplot(d.placebo.data, aes(x = traveltime, y = delta_antigov_share)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Diff. in vote share (opposition)") + xlab("Driving time (in minutes)") + labs(title = "Placebo test") + 
  theme(text = element_text(size=20)) 
p7
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/placebo_lm.pdf", device = "pdf", height = 6, width = 8)

p8 <- ggplot(d.placebo.data, aes(x = hkdist, y = delta_antigov_share)) + geom_point(color = "grey40") + geom_smooth(color = "red", method = "lm") + 
  ylab("Diff. in vote share (opposition)") + xlab("Straight-line distance (in kilometers)") + labs(title = "Placebo test") + 
  theme(text = element_text(size=20)) 
p8
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/placebo_dist_lm.pdf", device = "pdf", height = 6, width = 8)

# Figure 5
X <- names(HKdata)[c(2,4:7,10,15,29:30)]
d.data1 <- data.frame(d.data, HKdata[seq(2,802,2),X])
sens.formula1 <- paste0("delta_super_pan_share", "~", "traveltime", "+", paste0(X, collapse = "+"))
sens.formula2 <- paste0("delta_antigov_share", "~", "traveltime", "+", paste0(X[-8], collapse = "+"))
sens1 <- treatSens(as.formula(sens.formula1), data = d.data1)
sens2 <- treatSens(as.formula(sens.formula2), data = d.data1)
sensPlot(sens1)
sensPlot(sens2)

# Figure 6
HKES.data <- read.dta13("~/Dropbox/CurrentProjects/HKElection/WorkingData/HKElectionSurvey.dta", convert.factors = FALSE)
HKES.data1 <- HKES.data[HKES.data[, "vote_gov"] != 1 | HKES.data[, "vote_gov12"] != 1 , ]
HKES.data1 <- HKES.data1[!is.na(HKES.data1[, "weight_match"]) , ]
HKES.design <- svydesign(id=~1, weights=~wgtpost, data=HKES.data1)
HKES.nojoiner <- HKES.data1[HKES.data1[, "vote_dem_change"] != 1, ]
HKES.nojoiner.design <- svydesign(id=~1, weights=~wgtpost, data=HKES.nojoiner)
HKES.nodefector <- HKES.data1[HKES.data1[, "vote_dem_change"] != -1, ]
HKES.nodefector.design <- svydesign(id=~1, weights=~wgtpost, data=HKES.nodefector)
HKES.nostayer <- HKES.data1[HKES.data1[, "vote_dem_change"] != 0, ]
HKES.nostayer.design <- svydesign(id=~1, weights=~wgtpost, data=HKES.nostayer)

# travel time
mean.traveltime <- svyby(~traveltime, ~vote_dem_change, HKES.design, svymean)
ttest.traveltime.nojoiner <- svyttest(traveltime~vote_dem_change, HKES.nojoiner.design)
ttest.traveltime.nodefector <- svyttest(traveltime~vote_dem_change, HKES.nodefector.design)
ttest.traveltime.nostayer <- svyttest(traveltime~vote_dem_change, HKES.nostayer.design)
result.traveltime <- as.vector(c(mean.traveltime$traveltime, ttest.traveltime.nojoiner$estimate, 
                                 ttest.traveltime.nodefector$estimate, ttest.traveltime.nostayer$estimate))
se.traveltime.nodefector <- ttest.traveltime.nodefector$estimate / ttest.traveltime.nodefector$statistic
se.traveltime.nojoiner <- ttest.traveltime.nojoiner$estimate / ttest.traveltime.nojoiner$statistic
graph.traveltime <- rbind(as.vector(c(ttest.traveltime.nodefector$statistic,
                                      ttest.traveltime.nodefector$conf.int / se.traveltime.nodefector,
                                      confint(ttest.traveltime.nodefector, level = 0.9) / se.traveltime.nodefector)), 
                          -as.vector(c(ttest.traveltime.nojoiner$statistic,
                                       ttest.traveltime.nojoiner$conf.int / se.traveltime.nojoiner,
                                       confint(ttest.traveltime.nojoiner, level = 0.9) / se.traveltime.nojoiner)))

# contact politicians
mean.contact <- svyby(~contact, ~vote_dem_change, HKES.design, svymean)
ttest.contact.nojoiner <- svyttest(contact~vote_dem_change, HKES.nojoiner.design)
ttest.contact.nodefector <- svyttest(contact~vote_dem_change, HKES.nodefector.design)
ttest.contact.nostayer <- svyttest(contact~vote_dem_change, HKES.nostayer.design)
result.contact <- as.vector(c(mean.contact$contact, ttest.contact.nojoiner$estimate, 
                                 ttest.contact.nodefector$estimate, ttest.contact.nostayer$estimate))
se.contact.nodefector <- ttest.contact.nodefector$estimate / ttest.contact.nodefector$statistic
se.contact.nojoiner <- ttest.contact.nojoiner$estimate / ttest.contact.nojoiner$statistic
graph.contact <- rbind(as.vector(c(ttest.contact.nodefector$statistic,
                                      ttest.contact.nodefector$conf.int / se.contact.nodefector,
                                      confint(ttest.contact.nodefector, level = 0.9) / se.contact.nodefector)), 
                          -as.vector(c(ttest.contact.nojoiner$statistic,
                                       ttest.contact.nojoiner$conf.int / se.contact.nojoiner,
                                       confint(ttest.contact.nojoiner, level = 0.9) / se.contact.nojoiner)))

# gender
mean.gender <- svyby(~Q86, ~vote_dem_change, HKES.design, svymean)
ttest.gender.nojoiner <- svyttest(Q86~vote_dem_change, HKES.nojoiner.design)
ttest.gender.nodefector <- svyttest(Q86~vote_dem_change, HKES.nodefector.design)
ttest.gender.nostayer <- svyttest(Q86~vote_dem_change, HKES.nostayer.design)
result.gender <- as.vector(c(mean.gender$Q86, ttest.gender.nojoiner$estimate, 
                             ttest.gender.nodefector$estimate, ttest.gender.nostayer$estimate))
se.gender.nodefector <- ttest.gender.nodefector$estimate / ttest.gender.nodefector$statistic
se.gender.nojoiner <- ttest.gender.nojoiner$estimate / ttest.gender.nojoiner$statistic
graph.gender <- rbind(as.vector(c(ttest.gender.nodefector$statistic,
                                  ttest.gender.nodefector$conf.int / se.gender.nodefector,
                                  confint(ttest.gender.nodefector, level = 0.9) / se.gender.nodefector)), 
                      -as.vector(c(ttest.gender.nojoiner$statistic, 
                                   ttest.gender.nojoiner$conf.int / se.gender.nojoiner,
                                   confint(ttest.gender.nojoiner, level = 0.9) / se.gender.nojoiner)))


# age
mean.age <- svyby(~Q87, ~vote_dem_change, HKES.design, svymean)
ttest.age.nojoiner <- svyttest(Q87~vote_dem_change, HKES.nojoiner.design)
ttest.age.nodefector <- svyttest(Q87~vote_dem_change, HKES.nodefector.design)
ttest.age.nostayer <- svyttest(Q87~vote_dem_change, HKES.nostayer.design)
result.age <- as.vector(c(mean.age$Q87, ttest.age.nojoiner$estimate, 
                          ttest.age.nodefector$estimate, ttest.age.nostayer$estimate))
se.age.nodefector <- ttest.age.nodefector$estimate / ttest.age.nodefector$statistic
se.age.nojoiner <- ttest.age.nojoiner$estimate / ttest.age.nojoiner$statistic
graph.age <- rbind(as.vector(c(ttest.age.nodefector$statistic,
                               ttest.age.nodefector$conf.int / se.age.nodefector,
                               confint(ttest.age.nodefector, level = 0.9) / se.age.nodefector)), 
                   -as.vector(c(ttest.age.nojoiner$statistic, 
                                ttest.age.nojoiner$conf.int / se.age.nojoiner,
                                confint(ttest.age.nojoiner, level = 0.9) / se.age.nojoiner)))

# college
mean.college <- svyby(~college, ~vote_dem_change, HKES.design, svymean)
ttest.college.nojoiner <- svyttest(college~vote_dem_change, HKES.nojoiner.design)
ttest.college.nodefector <- svyttest(college~vote_dem_change, HKES.nodefector.design)
ttest.college.nostayer <- svyttest(college~vote_dem_change, HKES.nostayer.design)
result.college <- as.vector(c(mean.college$college, ttest.college.nojoiner$estimate, 
                              ttest.college.nodefector$estimate, ttest.college.nostayer$estimate))
se.college.nodefector <- ttest.college.nodefector$estimate / ttest.college.nodefector$statistic
se.college.nojoiner <- ttest.college.nojoiner$estimate / ttest.college.nojoiner$statistic
graph.college <- rbind(as.vector(c(ttest.college.nodefector$statistic,
                                   ttest.college.nodefector$conf.int / se.college.nodefector,
                                   confint(ttest.college.nodefector, level = 0.9) / se.college.nodefector)), 
                       -as.vector(c(ttest.college.nojoiner$statistic, 
                                    ttest.college.nojoiner$conf.int / se.college.nojoiner,
                                    confint(ttest.college.nojoiner, level = 0.9) / se.college.nojoiner)))


# income
mean.income <- svyby(~income, ~vote_dem_change, HKES.design, svymean)
ttest.income.nojoiner <- svyttest(income~vote_dem_change, HKES.nojoiner.design)
ttest.income.nodefector <- svyttest(income~vote_dem_change, HKES.nodefector.design)
ttest.income.nostayer <- svyttest(income~vote_dem_change, HKES.nostayer.design)
result.income <- as.vector(c(mean.income$income, ttest.income.nojoiner$estimate, 
                             ttest.income.nodefector$estimate, ttest.income.nostayer$estimate))
se.income.nodefector <- ttest.income.nodefector$estimate / ttest.income.nodefector$statistic
se.income.nojoiner <- ttest.income.nojoiner$estimate / ttest.income.nojoiner$statistic
graph.income <- rbind(as.vector(c(ttest.income.nodefector$statistic,
                                  ttest.income.nodefector$conf.int / se.income.nodefector,
                                  confint(ttest.income.nodefector, level = 0.9) / se.income.nodefector)), 
                      -as.vector(c(ttest.income.nojoiner$statistic, 
                                   ttest.income.nojoiner$conf.int / se.income.nojoiner,
                                   confint(ttest.income.nojoiner, level = 0.9) / se.income.nojoiner)))


# political knowledge
mean.knowledge <- svyby(~psop, ~vote_dem_change, HKES.design, svymean)
ttest.knowledge.nojoiner <- svyttest(psop~vote_dem_change, HKES.nojoiner.design)
ttest.knowledge.nodefector <- svyttest(psop~vote_dem_change, HKES.nodefector.design)
ttest.knowledge.nostayer <- svyttest(psop~vote_dem_change, HKES.nostayer.design)
result.knowledge <- as.vector(c(mean.knowledge$psop, ttest.knowledge.nojoiner$estimate, 
                                ttest.knowledge.nodefector$estimate, ttest.knowledge.nostayer$estimate))
se.knowledge.nodefector <- ttest.knowledge.nodefector$estimate / ttest.knowledge.nodefector$statistic
se.knowledge.nojoiner <- ttest.knowledge.nojoiner$estimate / ttest.knowledge.nojoiner$statistic
graph.knowledge <- rbind(as.vector(c(ttest.knowledge.nodefector$statistic,
                                     ttest.knowledge.nodefector$conf.int / se.knowledge.nodefector,
                                     confint(ttest.knowledge.nodefector, level = 0.9) / se.knowledge.nodefector)), 
                         -as.vector(c(ttest.knowledge.nojoiner$statistic, 
                                      ttest.knowledge.nojoiner$conf.int / se.knowledge.nojoiner,
                                      confint(ttest.knowledge.nojoiner, level = 0.9) / se.knowledge.nojoiner)))

# efficacy and economic insecurity
eff_econ_formula <- paste0("vote_dem", "~", "Q33", "+", "Q69")
eff_econ_reg <- lm(as.formula(eff_econ_formula), HKES.data1[HKES.data1$Q69 < 11, ], weights = HKES.data1[HKES.data1$Q69 < 11, "wgtpost"])
se.econ <- sqrt(vcov(eff_econ_reg)[2, 2])
se.eff <- sqrt(vcov(eff_econ_reg)[3, 3])
graph.econ <- as.vector(c(coef(eff_econ_reg)[2] / se.econ, confint(eff_econ_reg)[2, ] / se.econ, 
                                confint(eff_econ_reg, level = 0.9)[2, ] / se.econ))
graph.eff <- as.vector(c(coef(eff_econ_reg)[3] / se.eff, confint(eff_econ_reg)[3, ] / se.eff, 
                          confint(eff_econ_reg, level = 0.9)[3, ] / se.eff))


HKES.graph.data1 <- data.frame(rbind(graph.traveltime, graph.gender, graph.age, graph.college, graph.income, graph.knowledge, graph.contact))
HKES.graph.data2 <- data.frame(rbind(graph.econ, graph.eff))

names(HKES.graph.data1) <- names(HKES.graph.data2) <- c("coef", "CI.lower95", "CI.upper95", "CI.lower90", "CI.upper90")
HKES.graph.data1$names <- c("Travel time (joiner)", "Travel time (defector)", "Female (joiner)", "Female (defector)",
                           "Age (joiner)", "Age (defector)", "College degree (joiner)", "College degree (defector)", "Income (joiner)", "Income (defector)", 
                           "Political knowledge (joiner)", "Political knowledge (defector)", "Contact politicians (joiner)", "Contact politicians (defector)")
HKES.graph.data2$names <- c("Economic insecurity (2016)", "Political efficacy (2016)")

HKES.graph.data1$names <- factor(HKES.graph.data1$names, levels = rev(HKES.graph.data1$names))
HKES.graph.data2$names <- factor(HKES.graph.data2$names, levels = rev(HKES.graph.data2$names))

HKES.graph.data1$type <- rep(c(0,1), 7)
HKES.graph.data1$coef <- round(HKES.graph.data1$coef, 3)
HKES.graph.data1$CI.lower95 <- round(HKES.graph.data1$CI.lower95, 3)
HKES.graph.data1$CI.upper95 <- round(HKES.graph.data1$CI.upper95, 3)
HKES.graph.data1$CI.lower90 <- round(HKES.graph.data1$CI.lower90, 3)
HKES.graph.data1$CI.upper90 <- round(HKES.graph.data1$CI.upper90, 3)
HKES.graph.data2$coef <- round(HKES.graph.data2$coef, 3)
HKES.graph.data2$CI.lower95 <- round(HKES.graph.data2$CI.lower95, 3)
HKES.graph.data2$CI.upper95 <- round(HKES.graph.data2$CI.upper95, 3)
HKES.graph.data2$CI.lower90 <- round(HKES.graph.data2$CI.lower90, 3)
HKES.graph.data2$CI.upper90 <- round(HKES.graph.data2$CI.upper90, 3)

color <- c(ifelse(HKES.graph.data1$type==0, "red", "blue")[1:14])

p1 <- ggplot(HKES.graph.data1) + 
  geom_pointrange(aes(x=names, y=coef, ymin=CI.lower95, ymax=CI.upper95), colour=color, size = 0.3, lty = 2) + 
  geom_errorbar(aes(x=names, ymin=CI.lower90, ymax=CI.upper90), colour=color, size = 0.3) + theme_bw() + 
  coord_flip() + geom_hline(aes(yintercept = 0), colour = "black", lty=2) + xlab('') + ylab('') + ylim(-5.5, 5.5) + 
  theme(text = element_text(size=20)) 
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/HKES_comparison1.pdf", device = "pdf", height = 7, width = 8)

p2 <- ggplot(HKES.graph.data2) + 
  geom_pointrange(aes(x=names, y=coef, ymin=CI.lower95, ymax=CI.upper95), colour = "black", size = 0.3, lty = 2) + 
  geom_errorbar(aes(x=names, ymin=CI.lower90, ymax=CI.upper90), colour = "black", size = 0.3) + theme_bw() + 
  coord_flip() + geom_hline(aes(yintercept = 0), colour = "black", lty=2) + xlab('') + ylab('')+ ylim(-5.5, 5.5) + 
  theme(text = element_text(size=20)) 
ggsave("~/Dropbox/CurrentProjects/HKElection/Graph/HKES_comparison2.pdf", device = "pdf", height = 2, width = 8)

########################################################## Tables ######################################################################
HKdata <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/Wang_Wong_2017_Main.csv")
placebo.data <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/Wang_Wong_2017_Placebo.csv")
HKdata <- HKdata[,-1]
placebo.data <- placebo.data[,-1]

Y1 <- "super_pan_share"
Y2 <- "antigov_share"
Y3 <- "pan_share"
Y4 <- "local_share"
Y5 <- "super_weighted_ideology1"
Y6 <- "weighted_ideology1"
Y7 <- "turnout_rate"

Y_all <- c(Y1, Y2, Y3, Y4, Y5, Y6, Y7)
D <- "cross"
D1 <- "cross1"
D.fake <- "cross_fake"
D1.fake <- "cross1_fake"
Key <- "traveltime"
Key1 <- "hkdist"
unit <- "ccode"
period <- "post_umbrella"
FE <- c(unit, period)
cl <- "ccode"

HK.formula1 <- paste0(Y1, "~", D, "+", "factor(", period, ")")
HK.formula2 <- paste0(Y1, "~", D1, "+", "factor(", period, ")")
HK.formula3 <- paste0(Y2, "~", D, "+", "factor(", period, ")")
HK.formula4 <- paste0(Y2, "~", D1, "+", "factor(", period, ")")
HK.formula5 <- paste0(Y3, "~", D, "+", "factor(", period, ")")
HK.formula6 <- paste0(Y4, "~", D, "+", "factor(", period, ")")
HK.result1 <- plm(as.formula(HK.formula1), HKdata, index = unit)
HK.result2 <- plm(as.formula(HK.formula2), HKdata, index = unit)
HK.result3 <- plm(as.formula(HK.formula3), HKdata, index = unit)
HK.result4 <- plm(as.formula(HK.formula4), HKdata, index = unit)
HK.result5 <- plm(as.formula(HK.formula5), HKdata, index = unit)
HK.result6 <- plm(as.formula(HK.formula6), HKdata, index = unit)
HK.robust1 <- coeftest(HK.result1, vcov = vcovHC(HK.result1, type = "HC0", cluster = "group"))
HK.robust2 <- coeftest(HK.result2, vcov = vcovHC(HK.result2, type = "HC0", cluster = "group"))
HK.robust3 <- coeftest(HK.result3, vcov = vcovHC(HK.result3, type = "HC0", cluster = "group"))
HK.robust4 <- coeftest(HK.result4, vcov = vcovHC(HK.result4, type = "HC0", cluster = "group"))
HK.robust5 <- coeftest(HK.result5, vcov = vcovHC(HK.result5, type = "HC0", cluster = "group"))
HK.robust6 <- coeftest(HK.result6, vcov = vcovHC(HK.result6, type = "HC0", cluster = "group"))

stargazer(HK.robust1, HK.robust2, HK.robust3, HK.robust4, HK.robust5, HK.robust6, 
          covariate.labels = c("Driving time * Post Umbrella", "Straight-line * Post Umbrella", "Post Umbrella"), 
          star.cutoffs = c(0.05, 0.01, 0.001),
          digits = 3, keep = c("cross", "cross1", "post_umbrella"),
          title = "Table 1: Main Results", no.space = T)


# stargazer(HK.robust1[[2]], HK.robust2[[2]], HK.robust3[[2]], HK.robust4[[2]], HK.robust5[[2]], HK.robust6[[2]], 
#           covariate.labels = c("Driving time * Post Umbrella", "Straight-line * Post Umbrella", "Post Umbrella"), 
#           star.cutoffs = c(0.05, 0.01, 0.001),
#           digits = 3, keep = c("cross", "cross1", "post_umbrella"),
#           title = "Table 1: Main Results", no.space = T)

# Table 2
mediation.formula1 <- paste0(Y7, "~", D, "+", "factor(", period, ")")
direct.formula1 <- paste0(Y1, "~", Y7, "+", "factor(", period, ")")
mediation.formula2 <- paste0(Y7, "~", D1, "+", "factor(", period, ")")
direct.formula2 <- paste0(Y2, "~", Y7, "+", "factor(", period, ")")

turnout.result1 <- plm(as.formula(direct.formula1), data = HKdata, index = unit)
turnout.result2 <- plm(as.formula(direct.formula2), data = HKdata, index = unit)
turnout.result3 <- plm(as.formula(mediation.formula1), data = HKdata, index = unit)
turnout.result4 <- plm(as.formula(mediation.formula2), data = HKdata, index = unit)
turnout.robust1 <- coeftest(turnout.result1, vcov = vcovHC(turnout.result1, type = "HC0", cluster = "group"))
turnout.robust2 <- coeftest(turnout.result2, vcov = vcovHC(turnout.result2, type = "HC0", cluster = "group"))
turnout.robust3 <- coeftest(turnout.result3, vcov = vcovHC(turnout.result3, type = "HC0", cluster = "group"))
turnout.robust4 <- coeftest(turnout.result4, vcov = vcovHC(turnout.result4, type = "HC0", cluster = "group"))

stargazer(turnout.robust1, turnout.robust2, turnout.robust3, turnout.robust4, 
          covariate.labels = c("Turnout Rate", "Driving time * Post Umbrella", "Straight-line * Post Umbrella", "Post Umbrella"), 
          digits = 3, keep = c("turnout_rate", "cross", "cross1", "post_umbrella"), star.cutoffs = c(0.05, 0.01, 0.001),
          title = "Table 6: Results on Turnout", no.space = T)

# Table 3
idea.formula1 <- paste0(Y5, "~", D, "+", "factor(", period, ")")
idea.formula2 <- paste0(Y6, "~", D, "+", "factor(", period, ")")
idea.result1 <- plm(as.formula(idea.formula1), HKdata, index = unit)
idea.result2 <- plm(as.formula(idea.formula2), HKdata, index = unit)
idea.robust1 <- coeftest(idea.result1, vcov = vcovHC(idea.result1, type = "HC0", cluster = "group"))
idea.robust2 <- coeftest(idea.result2, vcov = vcovHC(idea.result2, type = "HC0", cluster = "group"))
section.VCOV1 <- cluster.boot.se(HK.formula1, HKdata, Y = Y1, D = D, X = NULL, FE = FE, cl = "district", nboots = 1000)
section.VCOV2 <- cluster.boot.se(HK.formula3, HKdata, Y = Y3, D = D, X = NULL, FE = FE, cl = "district", nboots = 1000)
section.robust1 <- coeftest(HK.result1, vcov = section.VCOV1)
section.robust2 <- coeftest(HK.result3, vcov = section.VCOV2)

location.data <- read.csv("/Users/yewang/Dropbox/CurrentProjects/HKElection/WorkingData/location.data.csv")
HKdata1 <- merge(HKdata, location.data, by = "ccode")
names(HKdata1)[157] <- "latitude"
m1 <-felm(super_pan_share ~ cross -1 | post_umbrella + ccode |0 |latitude +longitude,
         data = HKdata1, keepCX = TRUE)
coefficients(m1) %>% round(3)
m2 <-felm(antigov_share ~ cross -1 | post_umbrella + ccode |0 |latitude +longitude,
          data = HKdata1, keepCX = TRUE)
coefficients(m2) %>% round(3)

conley.se1 <- ConleySEs(reg = m1,
                       unit = "ccode", 
                       time = "post_umbrella",
                       lat = "latitude", lon = "longitude",
                       dist_fn = "SH", dist_cutoff = 50, 
                       lag_cutoff = 5,
                       cores = 1, 
                       verbose = FALSE) 

sapply(conley.se1, sqrt) %>% round(3)

conley.se2 <- ConleySEs(reg = m2,
                        unit = "ccode", 
                        time = "post_umbrella",
                        lat = "latitude", lon = "longitude",
                        dist_fn = "SH", dist_cutoff = 500, 
                        lag_cutoff = 5,
                        cores = 1, 
                        verbose = FALSE) 

sapply(conley.se2, sqrt) %>% round(3)


stargazer(idea.robust1, section.robust1, idea.robust2, section.robust2, 
          covariate.labels = c("Driving time * Post Umbrella", "Post Umbrella"), 
          digits = 3, keep = c("cross", "post_umbrella"), star.cutoffs = c(0.05, 0.01, 0.001),
          title = "Table 3: Alternative dependent variable and standard errors", no.space = T)

# # Table 4
# placebo.result1 <- plm(as.formula(HK.formula3), placebo.data[placebo.data$post_umbrella!=1,], index = unit)
# placebo.result2 <- plm(as.formula(HK.formula4), placebo.data[placebo.data$post_umbrella!=1,], index = unit)
# placebo.robust1 <- coeftest(placebo.result1, vcov = vcovHC(placebo.result1, type = "HC0", cluster = "group"))
# placebo.robust2 <- coeftest(placebo.result2, vcov = vcovHC(placebo.result2, type = "HC0", cluster = "group"))
# 
# placebo.formula1 <- paste0(Y1, "~", D, "+", D.fake, "+factor(", period, ")")
# placebo.formula2 <- paste0(Y2, "~", D, "+", D.fake, "+factor(", period, ")")
# placebo.result3 <- plm(as.formula(placebo.formula1), HKdata, index = unit)
# placebo.result4 <- plm(as.formula(placebo.formula2), HKdata, index = unit)
# placebo.robust3 <- coeftest(placebo.result3, vcov = vcovHC(placebo.result3, type = "HC0", cluster = "group"))
# placebo.robust4 <- coeftest(placebo.result4, vcov = vcovHC(placebo.result4, type = "HC0", cluster = "group"))
# stargazer(placebo.robust1[[2]], placebo.robust2[[2]], placebo.robust3[[2]], placebo.robust4[[2]], 
#           covariate.labels = c("Driving time * Post Umbrella", "Straight-line * Post Umbrella", "Driving time (placebo) ∗ Post Umbrella", "Post Umbrella"), 
#           digits = 3, keep = c("cross", "cross1", "cross_fake", "post_umbrella"), star.cutoffs = c(0.05, 0.01, 0.001),
#           title = "Table 4: Placebo Tests", no.space = T)


# Table 5A and 5B
ABS.data <- read.csv("~/Dropbox/CurrentProjects/HKElection/Replication/Wang_Wong_2017_Mechanisms.csv")
ABS.Y <- c("dem.pca", "eff.pca", "adv.pca", "econ.pca", "income")
ABS.X <- c("post_umbrella", "gender", "age", "age2", "married", "college")
ABS.D <- "cross1"
ABS.cl <- "district"
ABS.result1 <- list()
ABS.robust1 <- list()
ABS.result2 <- list()
ABS.robust2 <- list()

for (i in 1:length(ABS.Y)){
  ABS.data.i <- ABS.data[complete.cases(ABS.data[,ABS.Y[i]]),]
  ABS.formula1 <- paste0(ABS.Y[i], "~", ABS.D, "+", paste0(ABS.X, collapse = "+"))
  ABS.formula2 <- paste0(ABS.Y[i], "~", paste0(ABS.X, collapse = "+"))
  ABS.result1[[i]] <- plm(as.formula(ABS.formula1), data = ABS.data.i, index = ABS.cl)
  ABS.result2[[i]] <- plm(as.formula(ABS.formula2), data = ABS.data.i, index = ABS.cl)
  ABS.robust1[[i]] <- coeftest(ABS.result1[[i]], vcov = vcovHC(ABS.result1[[i]], type = "HC0", cluster = "group"))
  ABS.robust2[[i]] <- coeftest(ABS.result2[[i]], vcov = vcovHC(ABS.result2[[i]], type = "HC0", cluster = "group"))
}

stargazer(ABS.robust1[[1]], ABS.robust2[[1]], ABS.robust1[[2]], ABS.robust2[[2]], 
          ABS.robust1[[3]], ABS.robust2[[3]], covariate.labels = c("Driving time * Post Umbrella", "Post Umbrella"), 
          digits = 3, keep = c("cross", "post_umbrella"), star.cutoffs = c(0.05, 0.01, 0.001),
          title = "Table 5A: Mechanisms (Persuasion Effect)", no.space = T)

stargazer(ABS.robust1[[4]], ABS.robust2[[4]], ABS.robust1[[5]], ABS.robust2[[5]], 
          covariate.labels = c("Driving time * Post Umbrella", "Post Umbrella"), 
          digits = 3, keep = c("cross", "post_umbrella"), star.cutoffs = c(0.05, 0.01, 0.001),
          title = "Table 5B: Mechanisms (Socio-Economic Risks)", no.space = T)


# Table 6
HKES.data.long <- read.dta13("~/Dropbox/CurrentProjects/HKElection/WorkingData/HKElectionSurvey_long.dta", convert.factors = FALSE)
HKES.data.long$traveltime <- HKES.data.long$traveltime/60
HKES.data.long$hkdist <- HKES.data.long$hkdist/1000
HKES.data.long$cross <- HKES.data.long$cross/60
HKES.data.long$cross1 <- HKES.data.long$cross1/1000
HKES.formula1 <- paste0("vote_dem", "~", "cross", "+", "factor(", "post_umbrella", ")+factor(", "Pre_RecordNo", ")")
HKES.formula2 <- paste0("vote_dem", "~", "cross1", "+", "factor(", "post_umbrella", ")+factor(", "Pre_RecordNo", ")")
HKES.formula3 <- paste0("voted", "~", "cross", "+", "factor(", "post_umbrella", ")+factor(", "Pre_RecordNo", ")")
HKES.formula4 <- paste0("voted", "~", "cross1", "+", "factor(", "post_umbrella", ")+factor(", "Pre_RecordNo", ")")
HKES.result1 <- lm(as.formula(HKES.formula1), weights = HKES.data.long$wgtpost, HKES.data.long, index = "Pre_RecordNo")
HKES.result2 <- lm(as.formula(HKES.formula2), weights = HKES.data.long$wgtpost, HKES.data.long, index = "Pre_RecordNo")
HKES.result3 <- lm(as.formula(HKES.formula3), weights = HKES.data.long$wgtpost, HKES.data.long, index = "Pre_RecordNo")
HKES.result4 <- lm(as.formula(HKES.formula4), weights = HKES.data.long$wgtpost, HKES.data.long, index = "Pre_RecordNo")
HKES.robust1 <- coef_test(HKES.result1, vcov = "CR1", cluster = HKES.data.long$district, test = "naive-t")[c(1:3), ]
HKES.robust2 <- coef_test(HKES.result2, vcov = "CR1", cluster = HKES.data.long$district, test = "naive-t")[c(1:3), ]
HKES.robust3 <- coef_test(HKES.result3, vcov = "CR1", cluster = HKES.data.long$district, test = "naive-t")[c(1:3), ]
HKES.robust4 <- coef_test(HKES.result4, vcov = "CR1", cluster = HKES.data.long$district, test = "naive-t")[c(1:3), ]

HKES.robust1
HKES.robust2
HKES.robust3
HKES.robust4

stargazer(HKES.result1, HKES.result2, HKES.result3, HKES.result4, 
          covariate.labels = c("Driving time * Post Umbrella", "Straight-line * Post Umbrella", "Post Umbrella"), 
          digits = 3, keep = c("cross", "cross1", "post_umbrella"), star.cutoffs = c(0.05, 0.01, 0.001),
          title = "Table 6: Vote choice of HKES respondents", no.space = T)
